package com.example.greb;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.chaos.view.PinView;
import com.hbb20.CountryCodePicker;

public class PhoneLoginActivity extends AppCompatActivity {

    private CountryCodePicker ccp;
    private EditText phoneEdittext;
    private PinView firstPinView;
    private ConstraintLayout phoneLayout;
    private String selected_country_code = "+60";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_phone_login);

        ccp = findViewById(R.id.ccp);
        phoneEdittext = (EditText) findViewById(R.id.editTextTextPersonName);
        firstPinView= (PinView) findViewById(R.id.firstPinView);
        phoneLayout= (ConstraintLayout) findViewById(R.id.phoneLayout);


        ccp.setOnCountryChangeListener(new CountryCodePicker.OnCountryChangeListener() {
            @Override
            public void onCountrySelected() {
                selected_country_code = ccp.getSelectedCountryCodeWithPlus();

            }
        });

        //////////////////////country code picker///////////////////

        phoneEdittext.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(s.toString().length() == 10)
                {

                    Toast.makeText(PhoneLoginActivity.this, "heloooo", Toast.LENGTH_SHORT).show();
                    phoneLayout.setVisibility(View.GONE);
                    firstPinView.setVisibility(View.VISIBLE);
                }

            }



            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        //////////////////////phone text watcher///////////////////

        
    }
}