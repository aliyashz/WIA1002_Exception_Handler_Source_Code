package com.example.greb;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;

import com.blogspot.atifsoftwares.animatoolib.Animatoo;

public class LoginActivity extends AppCompatActivity {

    private Button phoneButton,googleButton;
    Animation phoneAnimate,googleAnimate;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        phoneButton = (Button) findViewById(R.id.button2);
        googleButton = (Button) findViewById(R.id.button);


        phoneAnimate = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.right_animation);
        googleAnimate = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.up_animation);

        phoneButton.setAnimation(phoneAnimate);
        googleButton.setAnimation(googleAnimate);


    }
    public void phoneLoginClick(View view){

        Intent intent = new Intent(LoginActivity.this, PhoneLoginActivity.class);
        startActivity(intent);
        Animatoo.animateSlideUp(this);

    }
}