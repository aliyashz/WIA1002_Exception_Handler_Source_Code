package com.example.greb;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.time.Instant;

public class MainActivity<MainActvity> extends AppCompatActivity {

    private TextView animatingText;
    Animation animateNow;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ////////hide status bar////////
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        ////////hide status bar////////

        ////////handler to redirect on next page on selected time//////

        new Handler().postDelayed(() -> {
            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();
        }, 3000);

        init();
    }

    private void init() {

        animatingText = (TextView) findViewById(R.id.textView2);
        ImageView marker = (ImageView) findViewById(R.id.imageView2);
        animateNow = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.up_animation);
        animatingText.setAnimation(animateNow);

        Glide.with(this).load(R.drawable.marker).into(marker);







    }
}


